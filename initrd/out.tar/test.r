echo hello
echo die
